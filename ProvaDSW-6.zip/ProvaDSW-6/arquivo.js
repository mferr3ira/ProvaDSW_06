const mysql = require('mysql2');


const connection = mysql.createConnection({
  host: 'localhost',
  user: 'matheus',
  password: 'matheus',
  database: 'escola'
});



connection.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados MySQL.');
});

const gravarAluno = (id, nome, email) => {
  const query = 'INSERT INTO aluno (id, nome, email) VALUES (?, ?, ?)';
  connection.query(query, [id, nome, email], (err, results) => {
    if (err) {
      console.error('Erro ao gravar dados:', err);
      return;
    }
    console.log('Dados gravados com sucesso:', results);
  });
};

const buscarAlunos = () => {
  const query = 'SELECT id, nome, email FROM aluno';
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Erro ao buscar dados:', err);
      return;
    }
    console.log('Dados dos alunos:');
    results.forEach((aluno) => {
      console.log(`ID: ${aluno.id}, Nome: ${aluno.nome}, Email: ${aluno.email}`);
    });
  });
};

gravarAluno(1, 'João Silva', 'joao.silva@example.com');
buscarAlunos();